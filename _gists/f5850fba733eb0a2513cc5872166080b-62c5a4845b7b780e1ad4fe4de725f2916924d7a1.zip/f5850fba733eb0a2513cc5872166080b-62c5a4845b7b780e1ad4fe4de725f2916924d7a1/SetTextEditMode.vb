Public Enum TextEditMode
   temcInvalid = 0
   temcLockedTrue = 2 ^ 1
   temcLockedFalse = 2 ^ 2
   temcEnabledTrue = 2 ^ 3
   temcEnabledFalse = 2 ^ 4
   temcEnterWithEdit = temcLockedFalse + temcEnabledTrue
   temcEnterNoEdit = temcLockedTrue + temcEnabledTrue
   temcNoEnterNormal = temcLockedTrue + temcEnabledFalse
   temcNoEnterDimmed = temcLockedFalse + temcEnabledFalse
End Enum

Public Function SetTextEditMode( _
   ByRef ctl As Control, _
   Optional ByVal temMode As TextEditMode) As TextEditMode

   ' Set or return the value of Enabled and Locked properties
   ' in a text based control to manage how it looks as follows:
   ' Enabled? Locked? Result?
   ' Yes Yes Can enter, can't edit, normal
   ' Yes No Can enter, can edit, normal
   ' No Yes Can't enter, can't edit, normal
   ' No No Can't enter, can't edit, dimmed
   ' If no mode requested then returns the current settings

   ' Developed by Warren Bain on 21/10/2005
   ' Copyright (c) Thought Croft Pty Ltd
   ' All rights reserved.

   ' Check we can do this for this type of control
   Select Case ctl.ControlType
      Case acComboBox, acCheckBox, acListBox, acTextBox
         If IsMissing(temMode) Then
            ' Let them know what is set
            SetTextEditMode = IIf(ctl.Enabled, temcEnabledTrue, temcEnabledFalse) + _
               IIf(ctl.Locked, temcLockedTrue, temcLockedFalse)
         Else
            ' Set the controls parameters
            ctl.Enabled = temMode And temcEnabledTrue
            ctl.Locked = temMode And temcLockedTrue
            SetTextEditMode = temMode
         End If
      Case Else
         SetTextEditMode = temcInvalid
      End Select
End Function