Private rps As ReportPrintStatus

Private Sub Report_Close()
   If rps.Printed Then
      ' Do something
    End If
End Sub

Private Sub Report_Open(Cancel As Integer)
   ' Sink the reports events so we can determine if it was printed or not
   Set rps = New ReportPrintStatus
   Set rps.Report = Me
End Sub