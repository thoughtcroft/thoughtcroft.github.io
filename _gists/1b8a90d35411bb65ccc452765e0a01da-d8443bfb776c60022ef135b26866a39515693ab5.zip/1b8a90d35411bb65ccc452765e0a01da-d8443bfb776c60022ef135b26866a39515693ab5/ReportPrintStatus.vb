' ReportPrintStatus class definition

' Use the hidden object type for a section so we can sink the events
' (thanks to Stephen Lebans for this tip - see www.lebans.com)

Private WithEvents mrpt As Access.Report
Private WithEvents msecReportHeader As Access.[_SectionInReport]
Private mintCounter As Integer

'--------------------------------
' Public Properties and Methods
'--------------------------------

Public Property Set Report(rpt As Access.Report)
   ' Sink the event handling for this report
   Const strEventKey As String = "[Event Procedure]"
   Set mrpt = rpt
   With mrpt
      ' If we don't populate these properties, the events will
      ' never fire in the report and we will be sunk!
      .OnActivate = strEventKey
      .OnClose = strEventKey
      .OnDeactivate = strEventKey
      ' Note, we assume this section exists - if not, it won't work
      Set msecReportHeader = .Section(acHeader)
      msecReportHeader.OnPrint = strEventKey
   End With
End Property

Public Property Get Printed() As Boolean
   ' Did they print this report?
   Printed = (mintCounter >= 1)
End Property

Public Sub Term()
   ' If we don't destroy these objects here, we risk an Access GPF!
   On Error Resume Next
   Set msecReportHeader = Nothing
   Set mrpt = Nothing
End Sub

'--------------------------------
' Event Procedures
'--------------------------------

Private Sub mrpt_Activate()
   ' This occurs if we open the report in print preview and also when
   ' we switch back to the previewed report in which case incremented
   ' by deactivate event
   mintCounter = mintCounter - 1
End Sub

Private Sub mrpt_Close()
   ' This occurs when the report closes so ensure we destroy objects
   ' to prevent an Access GPF
   Me.Term
End Sub

Private Sub mrpt_Deactivate()
   ' Called when we close report from preview or if we switch out of
   ' preview mode to another window in which case decremented by
   ' associated activate event
   mintCounter = mintCounter + 1
End Sub

Private Sub msecReportHeader_Print(Cancel As Integer, PrintCount As Integer)
   ' Increment our counter occurs once for every time we print and also
   ' the first time we open in preview mode
   mintCounter = mintCounter + 1
End Sub