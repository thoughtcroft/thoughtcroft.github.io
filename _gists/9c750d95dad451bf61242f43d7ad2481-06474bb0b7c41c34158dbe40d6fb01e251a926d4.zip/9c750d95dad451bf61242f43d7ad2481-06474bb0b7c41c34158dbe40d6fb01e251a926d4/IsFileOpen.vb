Public Function IsFileOpen(ByVal strFullPathFileName As String) As Boolean

   ' Attempting to open a file for ReadWrite that exists will fail
   ' if someone else has it open.  We also have to guard against the
   ' errors that occur if the file has uncommon file attributes such as
   ' 'hidden' which can upset the Open statement.
   ' NOTE: any open that doesn't lock the file such as opening a .txt file
   ' in NotePad or a read-only file open will return False from this call.

   Dim lngFile                    As Long
   Dim intAttrib                  As Integer

   On Error Resume Next
   intAttrib = GetAttr(strFullPathFileName)
   If Err <> 0 Then
       ' If we can't get these then it means the file name is
       ' invalid, or the file or path don't exist so no problem
       IsFileOpen = False
       Exit Function
   End If

   SetAttr strFullPathFileName, vbNormal
   If Err <> 0 Then
       ' An error here means that the file is open and the attributes
       ' therefore can't be changed so let them know that
       IsFileOpen = True
       Exit Function
   End If

   ' Ready to try and open the file exclusively and then any error means that
   ' the file is already open by some other process...
   lngFile = FreeFile
   Open strFullPathFileName For Random Access Read Write Lock Read Write As lngFile
   IsFileOpen = (Err <> 0)
   Close lngFile

   ' Restore the attributes and exit
   SetAttr strFullPathFileName, intAttrib

End Function