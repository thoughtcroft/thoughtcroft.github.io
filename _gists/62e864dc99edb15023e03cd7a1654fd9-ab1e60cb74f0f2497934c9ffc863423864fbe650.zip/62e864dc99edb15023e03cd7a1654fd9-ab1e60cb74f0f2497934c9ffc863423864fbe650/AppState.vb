' Class for defining an application state which can be
' saved and restored using the AppStateMgr class

' Developed by Warren Bain on 16/11/2006
' Copyright (c) Thought Croft Pty Ltd
' http:\\www.thoughtcroft.com
' All rights reserved.

Option Explicit

' Pointer calculated from the object used to index the state collection
' and the name of the application object this relates to
Private mstrIndex As String
Private mstrAppName As String

' Was the application instance created by us and how many are using it
Private mblnSelfStarted As Boolean
Private mlngObjectCount As Long

' Common application properties
Private mblnDisplayAlerts As Boolean
Private mblnScreenUpdating As Boolean
Private mblnVisible As Boolean
Private mlnghWnd As Long

' This one is only with Excel
Private meCalculation As Variant

Friend Property Get ObjectCount() As Long
    ObjectCount = mlngObjectCount
End Property

Friend Property Get DisplayAlerts() As Boolean
    DisplayAlerts = mblnDisplayAlerts
End Property

Friend Property Let DisplayAlerts(ByVal blnDisplayAlerts As Boolean)
    mblnDisplayAlerts = blnDisplayAlerts
End Property

Friend Property Get SelfStarted() As Boolean
    SelfStarted = mblnSelfStarted
End Property

Friend Property Let SelfStarted(ByVal blnSelfStarted As Boolean)
    mblnSelfStarted = blnSelfStarted
End Property

Friend Property Get ScreenUpdating() As Boolean
    ScreenUpdating = mblnScreenUpdating
End Property

Friend Property Let ScreenUpdating(ByVal blnScreenUpdating As Boolean)
    mblnScreenUpdating = blnScreenUpdating
End Property

Friend Property Get Visible() As Boolean
    Visible = mblnVisible
End Property

Friend Property Let Visible(ByVal blnVisible As Boolean)
    mblnVisible = blnVisible
End Property

Friend Property Get Index() As String
    Index = mstrIndex
End Property

Friend Property Let Index(ByVal strIndex As String)
    ' Can only assign this if the value is empty
    ' i.e. after it has been set, it is read only!
    If Len(mstrIndex) = 0 Then
        mstrIndex = strIndex
    Else
        Err.Raise vbObjectError + 5, "AppState", _
                  "Can't alter the Index after created!"
    End If
End Property

Friend Function IncrementCount() As Long
    ' Increase the count of objects using this application
    mlngObjectCount = mlngObjectCount + 1
    IncrementCount = mlngObjectCount
End Function

Friend Function DecrementCount() As Long
    ' Decrease the count of objects using this application
    mlngObjectCount = mlngObjectCount - 1
    DecrementCount = mlngObjectCount
End Function

Friend Property Get AppName() As String
    AppName = mstrAppName
End Property

Friend Property Let AppName(ByVal strAppName As String)
    ' Can only assign this if the value is empty
    ' i.e. after it has been set, it is read only!
    If Len(mstrAppName) = 0 Then
        mstrAppName = strAppName
    Else
        Err.Raise vbObjectError + 5, "AppState", _
                  "Can't alter the AppName after created!"
    End If
End Property

Friend Property Get Calculation() As Variant
    Calculation = meCalculation
End Property

Friend Property Let Calculation(ByVal eCalculation As Variant)
    meCalculation = eCalculation
End Property

Friend Property Get WindowsHandle() As Long
    WindowsHandle = mlnghWnd
End Property

Friend Property Let WindowsHandle(ByVal lngWindowsHandle As Long)
    mlnghWnd = lngWindowsHandle
End Property