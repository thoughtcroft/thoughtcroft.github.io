' Give this global scope
Public asm As AppStateMgr
Public app as Object

Set asm = New AppStateMgr
'
' Do something and decide we need to open Excel, say
'
Call asm.OpenApplication("Excel",app)
'
' Now open a workbook say and check for errors
'
If asm.CheckApplicationError(app,Err.Number) Then
   ' Something bad happened so deal with it
   ' If the error was catastrophic to Excel
   ' a new instance will be started anyway
Else
   ' Everything is fine, so something else
End If
'
' Finishing up now
'
Call asm.CloseApplication(app)
Set asm = Nothing