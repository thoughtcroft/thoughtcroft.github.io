Option Explicit

Public WithEvents oApp As Outlook.Application
Const TC_MAIL_ACCOUNT = "bainsworld"  ` change this to your account

Private Sub Class_Terminate()
   Set oApp = Nothing
End Sub

Private Sub oApp_NewMailEx(ByVal EntryIDCollection As String)

' This will be called whenever we receive new mail so
' process each item to determine if we should alter
' the account - do we need to worry about conflicts with Rules?

   Dim astrEntryIDs() As String
   Dim objItem As Object
   Dim varEntryID As Variant

   astrEntryIDs = Split(EntryIDCollection, ",")
   For Each varEntryID In astrEntryIDs
       Set objItem = oApp.Session.GetItemFromID(varEntryID)
       If objItem.Class = olMail Then
           ' Only call this for MailItems - can be ReadReceipts
           ' too which are class olReport
           Call SetEmailAccount(objItem)
       End If
   Next varEntryID
   Set objItem = Nothing
End Sub

Private Sub SetEmailAccount(ByRef oItem As MailItem)

' This code will check if the item is of interest to
' us and if so will update the account property accordingly

' Check if this was sent to the relevant address
   If CheckMessageRecipient(oItem, TC_MAIL_ACCOUNT, False) Then
       ' Yes it was - change the account
       Call SetMessageAccount(oItem, TC_MAIL_ACCOUNT, True)
   End If
End Sub

Private Sub Class_Initialize()
   Set oApp = Application
End Sub