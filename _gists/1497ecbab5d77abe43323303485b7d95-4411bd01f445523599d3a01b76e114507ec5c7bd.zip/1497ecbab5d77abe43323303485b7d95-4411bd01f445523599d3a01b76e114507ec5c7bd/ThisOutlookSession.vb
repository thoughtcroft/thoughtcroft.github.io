Dim MyNewMailHandler As clsNewMailHandler

Private Sub Application_Quit()
   Set MyNewMailHandler = Nothing
End Sub

Private Sub Application_Startup()
   Set MyNewMailHandler = New clsNewMailHandler
End Sub